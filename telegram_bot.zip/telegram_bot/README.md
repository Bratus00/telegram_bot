# Objetivo

> MBA FIAP

Bot Telegram criado com o objetivo acadêmia que faz parte do trabalho relacionado a disciplina Java do MBA Full Stack da instituição FIAP. 

---

### Categories

* [Configuração](#configuração)

---

### Configuração

 Para executar esse projeto é necessário ter o Java na sua máquina e configurar um arquivo chamado 
 
 token.properties na raiz do projeto, onde será utilizado o token para funcionamento do bot. Dentro do arquivo deve ser o seguinte texto  myToken: XXXXX.XXXXXXXXXXXXXX .

---
