package api;

public class ClimaTempo {
	
	//site https://advisor.climatempo.com.br
	//api http://apiadvisor.climatempo.com.br/api/v1/anl/synoptic/locale/BR?token=your-app-token

	//retorna os IDS da cidades
	//https://apiadvisor.climatempo.com.br/api/v1/locale/city?name=S%C3%A3o%20Paulo&token=f8a5a6b7c1a8be05f47c03616925df49
	
	 
	
}
