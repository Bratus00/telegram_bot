package business;

public interface Resposta {
    
    public void escuta(String ultimaInteracao);

    public String responde();
    
}
