package enums;

public enum MethodEnum {
	GET,POST,PUT,DELETE
}
