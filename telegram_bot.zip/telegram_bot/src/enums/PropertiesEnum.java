package enums;

/**
 * 
 * @author rafael
 * 
 */
public enum PropertiesEnum {
	/**
	 * token Telegram
	 */
	TELEGRAM,//telegram
	/**
	 * token Cripto
	 */
	NOMICS_API, //Cripto
	/**
	 * token Clima e tempo
	 */
	OPEN_WEATHER,//clima e tempo
	/**
	 * Traduto
	 */
	RAPID;  
}
