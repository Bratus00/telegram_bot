package telegram_bot;

public interface Resposta {
    
    public void escuta(String ultimaInteracao);

    public String responde();
    
}
