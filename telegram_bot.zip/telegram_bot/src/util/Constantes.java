package util;

public class Constantes {
	
	public final static String CRIPTO = "CRIPTO";
	public final static String CHUCK = "CHUCK NORRIS";
	public final static String OPEN_WEATHER = "CLIMA";
	public final static String SIM = "SIM";
	public final static String MENU = "MENU";
	public final static String NAO = "NAO";
	
}
